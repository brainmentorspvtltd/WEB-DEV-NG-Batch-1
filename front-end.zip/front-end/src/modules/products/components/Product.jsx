export const Product = ({prod})=>{
    const myStyle = {width: "18rem"};
    return (<div className="card" style={myStyle}>
    <img src={prod.image} className="card-img-top" alt="..."/>
    <div className="card-body">
      <h5 className="card-title">{prod.title}</h5>
      <p className="card-text">{prod.desc}</p>
      <a href="#" className="btn btn-primary">Add to Cart</a>
    </div>
  </div>);
}