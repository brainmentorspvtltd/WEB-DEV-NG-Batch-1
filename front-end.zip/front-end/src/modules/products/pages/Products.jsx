import {useEffect, useState} from 'react';
import getData from '../../../shared/services/api-client';
import { Product } from '../components/Product';
/*
ToDo
1. Products will be display , but first it do API Call
2. Once API Call gives the data , then loop it and print it
*/
export const Products = ()=>{
    const [products,setProducts] = useState([]);
    // Step - 1  Mounting Phase
    useEffect(()=>{
        loadProducts();
    },[]);

    const loadProducts = async ()=>{
        // read the Key from ENV
        const URL = import.meta.env.PRODUCTS_URL;
        console.log('URL from ENV ', URL);
        const products = await getData('https://fakestoreapi.com/products');
        setProducts(products);
        console.log('Products are ', products);
    }
    return (<div className='row'>
            {products.length==0?<p>Loading...</p>: 
            products.map(p=><Product prod={p}/>)}
    </div>) 
}