async function getData(URL){
    const response = await fetch(URL);
    const object = await response.json(); 
    // JSON convert it into object (DeSerialization)
    return object;
}
export default getData;