/*
 ToDo
 1. Click on any button , will print either X or 0
 1.1. But make sure the button is empty 
 1.2 If X is printed then turn for 0 and vice-versa

 2. Check whether game is over or not
 2.1 Check Game win or lose condition
 2.1.1  Row wise same (3) , Col Wise same (3) , Diagonal same (2). 
 make sure buttons are not empty. Total 8 Conditions
 2.1.2 Game win or lose check only if atleast 5 buttons clicked 
 2.1.3 Game Draw , if all button filled

 3. Game reset 
 3.1 After game win or lose or draw , game will be reset after 5 second
 3.1.1 - All buttons cleared
 3.1.2 - Turn reset
 3.1.3 - game message reset
*/

// 1. Click on any button , will print either X or 0
// attach click event on every button
// pick all the buttons
var buttons = document.getElementsByTagName('button');
console.log('Total Buttons are ', buttons.length);
for(var i = 0; i<buttons.length; i++){
    buttons[i].addEventListener('click', printXorZero);
}
var isXorZero = true;
function printXorZero(){
    var currentButton = this;
    currentButton.innerText = isXorZero?"X":"0";
    isXorZero = !isXorZero;
   // console.log('Print X or Zero Fn Call ', currentButton);
}

