/*
Makes Network call, Bring the Songs JSON
*/
function getSongs(singerName ='Sonu Nigam'){
    const URL = `https://itunes.apple.com/search?term=${singerName}&limit=25`;
    console.log("Start ");
    const promise = fetch(URL) ;// make api call
    // promise - Async 
    // Promise States = Pending , FullFilled , Rejected
    console.log("End");
    return promise;
}
export default getSongs;