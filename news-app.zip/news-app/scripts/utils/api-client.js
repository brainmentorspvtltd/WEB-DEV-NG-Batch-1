/*
Api client - to make api calls (WEB API / WebService)
*/
function getApiData(ENDPOINT_URL){
    // Promise - Proxy Object
    const promise = fetch(ENDPOINT_URL); // Async (Non Blocking)
    return promise;
    // CallBack / Promise / await
    // Promise  States
    // 1. Pending
    // 2. FullFilled
    // 3. Rejected
}
export default getApiData;
/*
function getHeadLines(){

}*/