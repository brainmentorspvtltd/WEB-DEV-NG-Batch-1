import NewsModel from "../models/news-model.js";
import getApiData from "../utils/api-client.js";

// This Service will get the HeadLines, Sports News, Business News
export async function getTopHeadLines(){
    try{
    const URL = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=11f0dc28d8874be0bb82287cbcf26121';
    const response = await getApiData(URL);
    // response = Header + Body
    const data =  await response.json();
    const news  = data.articles;
    // fill the news in model
    const newsmodel = news.map(n=>new NewsModel(n.title, n.description, n.url, n.urlToImage));
    return newsmodel;
    // All News (Generic Data) fill News Model (Specific Data)
    }
    catch(err){
        throw err;
    }
    //promise.then().catch()
    //return promise;
}
export function getSportsNews(){

}
export function getBusinessNews(){

}