class NewsModel{
    constructor(title, subtitle, link, image){
        this.title = title;
        this.subtitle = subtitle;
        this.link = link;
        this.image = image;
    }
}
export default NewsModel;