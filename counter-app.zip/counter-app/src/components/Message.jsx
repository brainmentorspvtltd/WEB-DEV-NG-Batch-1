// class A{

// }

export const Message = (props) => {
  return (
    <h1 className={props.css}>{props.msg} {props.val}</h1>
  )
}
