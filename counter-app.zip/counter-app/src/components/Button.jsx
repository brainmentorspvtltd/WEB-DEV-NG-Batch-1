export const Button = ({val, fn, css})=>{
    // return React.createElement('button');
    return (<button className={css} onClick ={fn}>{val}</button>)
}