import { CounterApp } from "./pages/CounterApp";


/*
What is Component
Component - Presentation
JS Function having JSX (JavaScript & XML)
Represent small view of big page
*/
function App(){
  return (<CounterApp/>);
}
export default App;