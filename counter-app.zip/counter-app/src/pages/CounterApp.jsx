
import { Message } from '../components/Message'
import { Button } from '../components/Button'
import { useState } from 'react'

export const CounterApp = () => {
    // Hook - Additional , Every hook start with use word
    const [counter, setCounter] = useState(0);
    const plus = ()=>{
        setCounter(counter+1); // Async 
        console.log('Plus ', counter);
    }
    const minus = ()=>{
        setCounter(counter-1);
        console.log('Minus ', counter);
    }
  return (
    <div className='container'>
        <Message msg = "Counter App" css = "alert alert-info text-center"/>
        <Message msg = "Count is " css ="alert alert-success" val = {counter}/>
        <Button css="btn btn-primary me-3" fn = {plus} val ="+"/>
        <Button css="btn btn-success" fn = {minus} val = "-"/>
    </div>
  )
}
