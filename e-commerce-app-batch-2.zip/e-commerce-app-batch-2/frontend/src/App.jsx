import { Home } from "./modules/products/pages/Home";

const App = ()=>{
  return (<Home/>)
}
export default App;